jQuery( function ( $ ) {
	
	$("form#create_custom_post").submit(function(e) {
		e.preventDefault();  
		file_data = $("#post_img").prop('files')[0];
		form_data = new FormData();
		
		var post_title=$("input[name=post_title]").val();
		var custom_post_types=$("select[name=custom_post_types]").val();
		var post_description=$("textarea[name=post_description]").val();
		var post_Excerpt=$("textarea[name=post_Excerpt]").val();
		
        form_data.append('file', file_data);
        form_data.append('post_title', post_title);
        form_data.append('custom_post_types', custom_post_types);
        form_data.append('post_description', post_description);
        form_data.append('post_Excerpt', post_Excerpt);
        form_data.append('action', 'save_custom_post_data');
        

		$.ajax({
			url: my_ajax_object.ajax_url,
			type: 'POST',
            contentType: false,
            processData: false,
            data: form_data,
			success: function (data) {
				if(data=="insert"){
					$("input[name=post_title]").val('');
					$("select[name=custom_post_types]").val('');
					$("textarea[name=post_description]").val('');
					$("textarea[name=post_Excerpt]").val('');
					$("#post_img").val('');
					$("#succ_msg").show();
					
				}
			},
			cache: false,
			
		});
	});
	

});
