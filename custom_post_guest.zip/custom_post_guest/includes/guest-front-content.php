<?php
function create_post_form($params, $content = null) {
	
	
    extract(shortcode_atts(array(
        'type' => 'style1'
    ), $params));

    ob_start();
	if(is_user_logged_in()) {
		$user = wp_get_current_user();
		
		$roles = ( array ) $user->roles;
		if($roles[0]=="author" || $roles[0]=="administrator") { ?>
			<form action="#"  class="custom_form" id="create_custom_post" name="create_custom_post" method="post" enctype="multipart/form-data">
				<ul>
					<li>
						<label>Post Title</label>
						<input name="post_title" type="text" id="post_title">
					</li>
					<li>
						<label>Select Post Type</label>
						<select  id="custom_post_types" name="custom_post_types">
						<?php
							 $args = array(
							   'public'   => true,
							);
							$output = 'names'; // names or objects, note names is the default
							$operator = 'or'; // 'and' or 'or'

							$post_types = get_post_types( $args, $output, $operator ); 
							
							foreach ( $post_types  as $post_type ) {
							   echo '<option value="'.$post_type.'">';
							   echo '<p>' . $post_type . '</p>';
							}
						?>
						</select>
					</li>
					<li>
						<label>Description</label>
						<textarea name="post_description" id="post_description"/></textarea>
					</li>
					
					<li>
						<label>Excerpt</label>
						<textarea name="post_Excerpt" id="post_Excerpt"></textarea>
					</li>
					<li>
						<label>Feature Image</label>
						<input type="file" name="post_img" id="post_img" >
					</li>

					<li>
						<input type="submit" name="save_post" id="save_post" value="Save Post">
					</li>
					<li>
						<p style="display:none" id="succ_msg">Post Inserted Successfull!</p>
					</li>
				 </ul>    
				</form>
		<?php }
	
	}
    ?>
    

<?php return ob_get_clean();
}
add_shortcode('display_post_insert_form','create_post_form');

add_action('wp_ajax_save_custom_post_data', 'save_custom_post_data');
add_action('wp_ajax_nopriv_save_custom_post_data', 'save_custom_post_data');

/**
 * Handles CTA AJAX.
 */
function save_custom_post_data(){
	
	$post_title=$_POST['post_title'];
	$custom_post_types=$_POST['custom_post_types'];
	$post_description=$_POST['post_description'];
	$post_Excerpt=$_POST['post_Excerpt'];
	
	$post_args = array(
		'post_title'    => $post_title,
		'post_content'  => $post_description,
		'post_status'   => 'draft',
		'post_type' => 'guest_post',
		'post_excerpt' =>$post_Excerpt
		);
		// insert the post into the database

		$last_post_id = wp_insert_post( $post_args, $wp_error);
	
	if(!empty($last_post_id)){
		update_post_meta($post_id,'_wporg_meta_key',$_POST['wporg_field']);
		$upload = wp_upload_bits($_FILES["file"]["name"], null, file_get_contents($_FILES["file"]["tmp_name"]));
		if ( ! $upload['error'] ) { 
		
			$filename = $upload['file'];
			$wp_filetype = wp_check_filetype($filename, null);
			$attachment = array(
				'post_mime_type' => $wp_filetype['type'],
				'post_title' => sanitize_file_name($filename),
				'post_content' => '',
				'post_status' => 'inherit'
			);

			$attachment_id = wp_insert_attachment( $attachment, $filename, $last_post_id );

			if ( ! is_wp_error( $attachment_id ) ) {
				require_once(ABSPATH . 'wp-admin/includes/image.php');

				$attachment_data = wp_generate_attachment_metadata( $attachment_id, $filename );
				wp_update_attachment_metadata( $attachment_id, $attachment_data );
				set_post_thumbnail( $last_post_id, $attachment_id );
			}
		}
	}
	
	if(!empty($last_post_id)){
		echo "insert";
		send_admin_email($last_post_id);
		
	}else{
		echo "error";
	}
	exit;
}

function send_admin_email($post_id){
    $to = get_bloginfo('admin_email');
    $subject = 'Author has inserted';
    $message = "From your site Author has insert post from front side. Check posts from admin. Post status is draft as of now. ";
    wp_mail($to, $subject, $message );
}

add_shortcode('guest_post_list','display_guest_post_list');
function display_guest_post_list($params, $content = null) {
	if(is_user_logged_in()) {
		$user = wp_get_current_user();
		$roles = ( array ) $user->roles;
		if($roles[0]=="author" || $roles[0]=="administrator") {
			global $post;
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 0;
			$postsPerPage = 1;
			$postOffset = $paged * $postsPerPage;

			$args = array(
				'numberposts'	=> -1,
				"post_type" => "guest_post",
				'post_status'=>'draft',
				'offset'          => $postOffset,
				'posts_per_page'  => $postsPerPage,
			);
			$guest_posts = new WP_Query( $args );
			 if ( $guest_posts->have_posts() ) {
				while ( $guest_posts->have_posts() ) { 
					$guest_posts->the_post();
					$postId=get_the_id();
					
					$image = wp_get_attachment_image_src( get_post_thumbnail_id( $postId ), 'single-post-thumbnail' );?> 
					<div style="width:100%;float:left;">
						<img height="50px" width="50px" src="<?php echo $image[0]; ?>" /><br>
						<label style="float:left;width:250px">Title</label><h4 style="float:right"><?php  the_title(); ?></h4>
						<label style="float:left;width:250px">Description</label><h5 style="float:right"><?php echo $guest_posts->post_content ?></h4>
						<label style="float:left;width:250px">Excerpt</label><h5 style="float:right"><?php echo $guest_posts->post_excerpt; ?></h4>
					</div>
					
				<?php
				}
				next_posts_link( 'Older Entries', $guest_posts->max_num_pages );
				previous_posts_link( 'Next Entries &raquo;' ); 
				wp_reset_postdata();
			}
		}
	}	
}



