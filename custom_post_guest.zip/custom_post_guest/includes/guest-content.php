<?php

function guest_register_post_type() {
 
    // Guest
 
    $labels = array( 
 
        'name' => __( 'Guest Post' , 'guest_post' ),
 
        'singular_name' => __( 'Guest Post' , 'guest_post' ),
 
        'add_new' => __( 'New Guest Post' , 'guest_post' ),
 
        'add_new_item' => __( 'Add New Guest Post' , 'guest_post' ),
 
        'edit_item' => __( 'Edit Guest Post' , 'guest_post' ),
 
        'new_item' => __( 'New Guest Post' , 'guest_post' ),
 
        'view_item' => __( 'View Guest Post' , 'guest_post' ),
 
        'search_items' => __( 'Search Guest Post' , 'guest_post' ),
 
        'not_found' =>  __( 'No Guest Post Found' , 'guest_post' ),
 
        'not_found_in_trash' => __( 'No Guest Post found in Trash' , 'guest_post' ),
 
    );
 
    $args = array(
 
        'labels' => $labels,
 
        'has_archive' => true,
 
        'public' => true,
 
        'hierarchical' => false,
 
        'supports' => array(
 
            'title', 
 
            'editor', 
 
            'excerpt', 
 
            'custom-fields', 
 
            'thumbnail',
 
            'page-attributes'
 
        ),
 
        'rewrite'   => array( 'slug' => 'guest_post' ),
 
        'show_in_rest' => true
 
    );
	register_post_type( 'guest_post', $args );
 
}
add_action( 'init', 'guest_register_post_type' );


/* Adding metabox for dropdown selection from custom post type */
add_action( 'admin_init', 'custom_post_type_selection' );

function custom_post_type_selection() {
    add_meta_box( 'guest_post_meta_box',
        'Select Custom post',
        'display_guest_post_meta_box',
        'guest_post', 'normal', 'high'
    );
}

function custom_meta_save_postdata( $post_id ) {
    if ( array_key_exists( 'custom_post_types_field_meta', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_custom_post_types_field_meta',
            $_POST['custom_post_types_field_meta']
        );
    }
}
add_action( 'save_post', 'custom_meta_save_postdata' );

/* Function to display post type dropdown in backend */
function display_guest_post_meta_box( $guest_post ) {
    // Retrive the current post ID
    $guest_post_ID = $guest_post->ID;
   
    ?>
    <table>
        
        <tr>
            <td style="width: 150px">Custom Post List</td>
            <td>
			<?php  $value = get_post_meta( $guest_post->ID, '_custom_post_types_field_meta', true ); ?>
                <select style="width: 100px" name="custom_post_types_field_meta">
                <?php
               $args = array(
				   'public'   => true,
				);

				$output = 'names'; // names or objects, note names is the default
				$operator = 'or'; // 'and' or 'or'

				$post_types = get_post_types( $args, $output, $operator ); 
				
				foreach ( $post_types  as $post_type ) {
					if($value==$post_type){
						$selected="selected";
					}
				   echo '<option selected="'.$selected.'" value="'.$post_type.'">';
				   echo '<p>' . $post_type . '</p>';
				} ?>
                </select>
            </td>
        </tr>
    </table>
    <?php
}