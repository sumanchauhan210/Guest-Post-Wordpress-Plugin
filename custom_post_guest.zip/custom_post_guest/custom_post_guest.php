<?php
/*
 
Plugin Name: Guest Post Types
 
Plugin URI: 
 
Description: Plugin to create Guest custom post type for user role author and provide functinality to submit post from front end UI.
 Use short code:[guest_post_list] to display list of guest posts which has status draft and inserted by author/admin user role
 Use short code: [display_post_insert_form] to display form on front side on any page to display front side form it will only display for user role author/admin
Version: 1.0
 
Author: Suman Chauhan
 
Author URI: 
 
License: Phase1
 
*/

require( dirname(__FILE__) . '/../../../wp-load.php' );
include( plugin_dir_path( __FILE__ ) . 'includes/guest-content.php' );
include( plugin_dir_path( __FILE__ ) . 'includes/guest-front-content.php' );
$wordpress_upload_dir = wp_upload_dir();

function guest_post_styles() {
    wp_enqueue_style( 'guest_post',  plugin_dir_url( __FILE__ ) . '/css/guest_post.css');                      
    wp_enqueue_script( 'jquery','//ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js');
    wp_enqueue_script( 'guest_post',  plugin_dir_url( __FILE__ ) . '/js/guest_post.js');
	//wp_enqueue_script( 'ajax-script', get_template_directory_uri() . '/js/my-ajax-script.js', array('jquery') );
    wp_localize_script( 'guest_post', 'my_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );//my_ajax_object.ajax_url,	
}
add_action( 'wp_enqueue_scripts', 'guest_post_styles' );

add_action('init', 'use_jquery_from_google');

function use_jquery_from_google () {
	if (is_admin()) {
		return;
	}

	global $wp_scripts;
	if (isset($wp_scripts->registered['jquery']->ver)) {
		$ver = $wp_scripts->registered['jquery']->ver;
                $ver = str_replace("-wp", "", $ver);
	} else {
		$ver = '1.12.4';
	}

	wp_deregister_script('jquery');
	wp_register_script('jquery', "//ajax.googleapis.com/ajax/libs/jquery/$ver/jquery.min.js", false, $ver);
}